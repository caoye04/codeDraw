class BasePlayer:
    def __init__(self) -> None:
        pass
    
    def play(self, state) -> int:
        raise NotImplementedError